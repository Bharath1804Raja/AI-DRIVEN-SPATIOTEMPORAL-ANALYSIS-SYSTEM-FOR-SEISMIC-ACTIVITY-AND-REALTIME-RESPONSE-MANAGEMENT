"use client"

import { useState } from "react"
import { GlobalNavigation } from "@/components/global-navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ChatbotWidget } from "@/components/chatbot-widget"
import { ProbabilisticRiskModule } from "@/components/probabilistic-risk-module"

interface SelectedLocation {
  place: string
  mag: number
  lat: number
  lng: number
  time: string
  depth: number
}

export default function HomePage() {
  const [selectedLocation, setSelectedLocation] = useState<SelectedLocation | null>(null)

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <GlobalNavigation />
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 p-6 max-w-7xl mx-auto">
        {/* Main Content */}
        <div className="lg:col-span-3">
          <DashboardLayout selectedLocation={selectedLocation} onLocationSelect={setSelectedLocation} />
        </div>
        {/* Probabilistic Risk Module */}
        <div className="lg:col-span-1">
          <ProbabilisticRiskModule />
        </div>
      </div>
      <ChatbotWidget />
    </main>
  )
}
