"use client"

import { PredictionExplorer } from "@/components/prediction-explorer"
import { RiskVisualizationMap } from "@/components/risk-visualization-map"
import { GlobalNavigation } from "@/components/global-navigation"
import { TopPredictionsDisplay } from "@/components/top-predictions-display"
import { HistoricalPredictionsView } from "@/components/historical-predictions-view"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useState } from "react"

export default function PredictionsPage() {
  const [viewMode, setViewMode] = useState("current")

  // Sample risk zones for demonstration
  const sampleRiskZones = [
    { lat: 35.7, lng: 139.7, probability: 0.65, radius: 100, magnitude: [5.5, 7.0] as [number, number] },
    { lat: 37.9, lng: 141.8, probability: 0.52, radius: 120, magnitude: [5.0, 6.5] as [number, number] },
    { lat: -33.9, lng: -71.3, probability: 0.58, radius: 150, magnitude: [6.0, 7.5] as [number, number] },
    { lat: 40.7, lng: -124.0, probability: 0.42, radius: 80, magnitude: [4.5, 6.0] as [number, number] },
  ]

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <GlobalNavigation />
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        <div className="max-w-7xl mx-auto space-y-6 lg:space-y-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">AI-Powered Earthquake Predictions</h1>
            <p className="text-gray-400 text-sm sm:text-base">Advanced ML models forecasting seismic activity for up to 1 year ahead</p>
          </div>

          <Tabs value={viewMode} onValueChange={setViewMode} className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3 bg-slate-800/50">
              <TabsTrigger value="current">Top 10 Regions</TabsTrigger>
              <TabsTrigger value="historical">Historical (45d)</TabsTrigger>
              <TabsTrigger value="map" className="hidden lg:inline-flex">Live Map</TabsTrigger>
            </TabsList>

            <TabsContent value="current" className="space-y-4">
              <TopPredictionsDisplay riskZones={sampleRiskZones} />
            </TabsContent>

            <TabsContent value="historical" className="space-y-4">
              <HistoricalPredictionsView />
            </TabsContent>

            <TabsContent value="map" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                  <PredictionExplorer />
                </div>
                <div className="lg:col-span-2">
                  <RiskVisualizationMap riskZones={sampleRiskZones} height="600px" />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}
