"use client"

import { GlobalNavigation } from "@/components/global-navigation"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertTriangle, Phone, MapPin, BookOpen } from "lucide-react"
import { useState } from "react"

const COUNTRY_EMERGENCY_DATA: Record<string, any> = {
  JP: {
    name: "Japan",
    emergencyNumber: "110 (Police) / 119 (Ambulance)",
    earthquakeHotline: "03-3211-0011",
    shelters: [
      { name: "Tokyo Metropolitan Building", lat: 35.6895, lng: 139.7671 },
      { name: "Yoyogi Park Shelter", lat: 35.6734, lng: 139.7003 },
      { name: "Odaiba Disaster Prevention Center", lat: 35.6294, lng: 139.7558 },
    ],
  },
  TR: {
    name: "Turkey",
    emergencyNumber: "112",
    earthquakeHotline: "0212-567-1234",
    shelters: [
      { name: "Istanbul Convention Center", lat: 41.077, lng: 29.0066 },
      { name: "Ümraniye Emergency Shelter", lat: 41.0275, lng: 29.1181 },
    ],
  },
  IN: {
    name: "India",
    emergencyNumber: "112 / 100",
    earthquakeHotline: "1077",
    shelters: [
      { name: "New Delhi Convention Center", lat: 28.5355, lng: 77.249 },
      { name: "Mumbai Emergency Relief Center", lat: 19.076, lng: 72.8777 },
      { name: "Ahmedabad Relief Shelter", lat: 23.0225, lng: 72.5714 },
    ],
  },
  US: {
    name: "United States",
    emergencyNumber: "911",
    earthquakeHotline: "1-800-USGS-ASK",
    shelters: [
      { name: "San Francisco Convention Center", lat: 37.7841, lng: -122.395 },
      { name: "Los Angeles Convention Center", lat: 34.4194, lng: -118.268 },
    ],
  },
  MX: {
    name: "Mexico",
    emergencyNumber: "911",
    earthquakeHotline: "5555-1435",
    shelters: [
      { name: "Mexico City Metropolitan Center", lat: 19.4343, lng: -99.1332 },
      { name: "Guadalajara Emergency Center", lat: 20.6637, lng: -103.276 },
    ],
  },
  CL: {
    name: "Chile",
    emergencyNumber: "911 / 133",
    earthquakeHotline: "1410",
    shelters: [
      { name: "Santiago Emergency Center", lat: -33.4489, lng: -70.6693 },
      { name: "Valparaíso Relief Center", lat: -33.0458, lng: -71.6196 },
    ],
  },
}

export default function EmergencyPage() {
  const [selectedCountry, setSelectedCountry] = useState("US")
  const countryData = COUNTRY_EMERGENCY_DATA[selectedCountry]

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <GlobalNavigation />

      <div className="flex-1 p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-white">Emergency & Preparedness</h1>
            <p className="text-slate-400">Safety guidance, emergency contacts, and shelter information</p>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Before & During Shaking */}
            <Card className="bg-slate-800/50 border-cyan-500/20 p-6 lg:col-span-2">
              <h3 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                Safety During Shaking
              </h3>

              <Tabs defaultValue="before" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                  <TabsTrigger value="before">Before</TabsTrigger>
                  <TabsTrigger value="during">During</TabsTrigger>
                  <TabsTrigger value="after">After</TabsTrigger>
                </TabsList>

                <TabsContent value="before" className="space-y-4 mt-6">
                  <div className="bg-slate-700/30 p-4 rounded border border-slate-600/30 space-y-3">
                    <div className="flex gap-3">
                      <div className="text-green-400 font-bold">1.</div>
                      <div>
                        <h4 className="font-semibold text-white">Secure Heavy Furniture</h4>
                        <p className="text-slate-300 text-sm">
                          Anchor bookcases, shelving units, and appliances to walls using L-brackets and straps.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-green-400 font-bold">2.</div>
                      <div>
                        <h4 className="font-semibold text-white">Know Safe Spots</h4>
                        <p className="text-slate-300 text-sm">
                          Identify sturdy tables and against interior walls in your home, workplace, and school.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-green-400 font-bold">3.</div>
                      <div>
                        <h4 className="font-semibold text-white">Prepare Emergency Kit</h4>
                        <p className="text-slate-300 text-sm">
                          Assemble water (1 gallon/person/day), non-perishable food, first-aid kit, medications,
                          flashlight, batteries, and radio.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-green-400 font-bold">4.</div>
                      <div>
                        <h4 className="font-semibold text-white">Practice Drills</h4>
                        <p className="text-slate-300 text-sm">
                          Conduct monthly earthquake drills with family members. Everyone should know what to do.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="during" className="space-y-4 mt-6">
                  <div className="bg-slate-700/30 p-4 rounded border border-red-600/30 space-y-3">
                    <div className="flex gap-3">
                      <div className="text-red-400 font-bold">DROP</div>
                      <div>
                        <h4 className="font-semibold text-white">Immediately get down on hands and knees</h4>
                        <p className="text-slate-300 text-sm">
                          Do not run outside. You are more likely to be injured by falling objects when running than by
                          remaining indoors.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-red-400 font-bold">COVER</div>
                      <div>
                        <h4 className="font-semibold text-white">
                          Take cover under a sturdy desk/table or against an interior wall
                        </h4>
                        <p className="text-slate-300 text-sm">
                          Protect your head and neck with your arms. If not available, crouch in a corner away from
                          windows.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-red-400 font-bold">HOLD ON</div>
                      <div>
                        <h4 className="font-semibold text-white">Hold on until shaking stops</h4>
                        <p className="text-slate-300 text-sm">
                          Do not move or run. Remain in your protective position for at least 60 seconds after shaking
                          stops.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="after" className="space-y-4 mt-6">
                  <div className="bg-slate-700/30 p-4 rounded border border-amber-600/30 space-y-3">
                    <div className="flex gap-3">
                      <div className="text-amber-400 font-bold">1.</div>
                      <div>
                        <h4 className="font-semibold text-white">Check for Injuries</h4>
                        <p className="text-slate-300 text-sm">
                          Perform first aid on anyone who is hurt. Call emergency services for serious injuries.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-amber-400 font-bold">2.</div>
                      <div>
                        <h4 className="font-semibold text-white">Inspect Property</h4>
                        <p className="text-slate-300 text-sm">
                          Check for gas leaks, broken electrical wires, and structural damage. Evacuate if the building
                          is unsafe.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-amber-400 font-bold">3.</div>
                      <div>
                        <h4 className="font-semibold text-white">Stay Informed</h4>
                        <p className="text-slate-300 text-sm">
                          Listen to local news and official emergency alerts for updates and instructions.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-amber-400 font-bold">4.</div>
                      <div>
                        <h4 className="font-semibold text-white">Expect Aftershocks</h4>
                        <p className="text-slate-300 text-sm">
                          Aftershocks may follow the main earthquake. Be prepared to take shelter again if needed.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>

            {/* Emergency Contacts Sidebar */}
            <Card className="bg-slate-800/50 border-cyan-500/20 p-6 h-fit">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Phone className="w-5 h-5 text-red-400" />
                Quick Emergency
              </h3>

              <div className="mb-4">
                <label className="text-sm text-slate-300 mb-2 block">Select Country/Region:</label>
                <select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-700/50 border border-cyan-500/30 text-white text-sm"
                >
                  {Object.entries(COUNTRY_EMERGENCY_DATA).map(([code, data]) => (
                    <option key={code} value={code}>
                      {data.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-3">
                <div className="bg-red-500/10 border border-red-500/30 p-3 rounded">
                  <p className="text-xs text-slate-400 mb-1">General Emergency</p>
                  <p className="text-lg font-bold text-red-300">{countryData.emergencyNumber}</p>
                </div>

                <div className="bg-orange-500/10 border border-orange-500/30 p-3 rounded">
                  <p className="text-xs text-slate-400 mb-1">Earthquake Hotline</p>
                  <p className="text-lg font-bold text-orange-300">{countryData.earthquakeHotline}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Shelters & Resources */}
          <Card className="bg-slate-800/50 border-cyan-500/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-400" />
              Designated Shelters in {countryData.name}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {countryData.shelters.map((shelter: any, idx: number) => (
                <div key={idx} className="bg-slate-700/30 p-4 rounded border border-blue-500/30">
                  <h4 className="font-semibold text-cyan-300 mb-2">{shelter.name}</h4>
                  <p className="text-sm text-slate-400">
                    📍 {shelter.lat.toFixed(4)}°N, {Math.abs(shelter.lng).toFixed(4)}°{shelter.lng > 0 ? "E" : "W"}
                  </p>
                </div>
              ))}
            </div>
          </Card>

          {/* Resources */}
          <Card className="bg-slate-800/50 border-cyan-500/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-green-400" />
              Additional Resources
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <a
                href="https://www.redcross.org/get-help/disaster-relief-and-recovery/disaster-preparedness.html"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-slate-700/30 rounded border border-cyan-500/30 hover:border-cyan-500/60 transition"
              >
                <span className="text-2xl">🏥</span>
                <div>
                  <p className="font-semibold text-cyan-300">Red Cross Preparedness</p>
                  <p className="text-xs text-slate-400">Official safety guidelines</p>
                </div>
              </a>

              <a
                href="https://www.fema.gov/disaster/earthquake"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-slate-700/30 rounded border border-cyan-500/30 hover:border-cyan-500/60 transition"
              >
                <span className="text-2xl">🛡️</span>
                <div>
                  <p className="font-semibold text-cyan-300">FEMA Earthquake Guide</p>
                  <p className="text-xs text-slate-400">Comprehensive disaster prep</p>
                </div>
              </a>

              <a
                href="https://earthquake.usgs.gov/earthquakes/map/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-slate-700/30 rounded border border-cyan-500/30 hover:border-cyan-500/60 transition"
              >
                <span className="text-2xl">🌍</span>
                <div>
                  <p className="font-semibold text-cyan-300">USGS Real-time Map</p>
                  <p className="text-xs text-slate-400">Live earthquake tracking</p>
                </div>
              </a>

              <a
                href="https://earthquake.usgs.gov/earthquakes/prediction/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-slate-700/30 rounded border border-cyan-500/30 hover:border-cyan-500/60 transition"
              >
                <span className="text-2xl">📊</span>
                <div>
                  <p className="font-semibold text-cyan-300">Earthquake Hazard Maps</p>
                  <p className="text-xs text-slate-400">Regional risk assessments</p>
                </div>
              </a>
            </div>
          </Card>
        </div>
      </div>
    </main>
  )
}
